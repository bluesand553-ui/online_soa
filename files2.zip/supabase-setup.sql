-- Statement of Account: run once in Supabase -> SQL Editor
create table if not exists public.txns (
  id uuid primary key default gen_random_uuid(),
  type text not null check (type in ('income', 'expense')),
  tx_date date not null,
  item text not null default '',
  description text not null default '',
  quantity text not null default '1',
  amount numeric not null default 0,
  remarks text not null default '',
  created bigint not null default 0,
  recorded_by text,
  acct text
);
create index if not exists txns_acct_date_idx on public.txns (acct, tx_date);

create table if not exists public.settings (
  id text primary key,
  data jsonb not null default '{}'::jsonb
);

-- Only signed-in users can read or write. No public access.
alter table public.txns enable row level security;
alter table public.settings enable row level security;

drop policy if exists "authenticated full access" on public.txns;
create policy "authenticated full access" on public.txns
  for all to authenticated using (true) with check (true);

drop policy if exists "authenticated full access" on public.settings;
create policy "authenticated full access" on public.settings
  for all to authenticated using (true) with check (true);

-- Live updates between users (safe to re-run)
do $$ begin
  alter publication supabase_realtime add table public.txns;
exception when duplicate_object then null; end $$;
do $$ begin
  alter publication supabase_realtime add table public.settings;
exception when duplicate_object then null; end $$;
